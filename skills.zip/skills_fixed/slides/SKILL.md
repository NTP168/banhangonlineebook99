---
name: slides
description: Tạo bộ trình chiếu HTML chuyên nghiệp (Slide Generator). Kích hoạt khi người dùng gõ "slides", "tạo slide", "làm presentation", "trình chiếu về". Tự động tạo bộ slide HTML hoàn chỉnh với animation mượt, thiết kế đẹp từ một mô tả đơn giản. Tiết kiệm 3 giờ làm PowerPoint.
---

# 📊 Slide Generator Skill

## Mục tiêu
Từ một câu mô tả → bộ trình chiếu HTML hoàn chỉnh, có thể mở ngay trên trình duyệt, animation mượt, thiết kế chuyên nghiệp.

## Khi nào kích hoạt
- Người dùng gõ: `slides [chủ đề]`, `tạo slide về X`, `làm presentation X`
- Ví dụ: `slides chiến lược marketing Q4`, `tạo slide giới thiệu sản phẩm`

## Quy trình thực hiện

### Bước 1 — Thu thập yêu cầu
Hỏi nhanh:
- Chủ đề/tiêu đề chính là gì?
- Đối tượng nghe? (sếp, khách hàng, team, học sinh...)
- Số slide mong muốn? (mặc định: 8-12 slide)
- Tone? (formal/professional / casual / creative)
- Màu sắc thương hiệu? (nếu có)

### Bước 2 — Lên outline
Tạo outline trước, confirm với người dùng:
```
Slide 1: Cover / Tiêu đề
Slide 2: Agenda / Mục lục
Slide 3-9: Nội dung chính
Slide 10: Key Takeaways
Slide 11: Q&A / Cảm ơn
```

### Bước 3 — Tạo HTML Slides

Tạo file HTML với cấu trúc:

```html
<!DOCTYPE html>
<html>
<head>
  <style>
    /* Dark professional theme */
    /* Navigation với phím mũi tên */
    /* Animation: fade, slide */
    /* Progress bar */
    /* Responsive */
  </style>
</head>
<body>
  <div class="slideshow">
    <!-- Mỗi slide là 1 section -->
    <section class="slide active">...</section>
    <section class="slide">...</section>
  </div>
  
  <!-- Navigation -->
  <div class="nav">
    <button onclick="prevSlide()">◀</button>
    <span id="counter">1/10</span>
    <button onclick="nextSlide()">▶</button>
  </div>
  
  <script>
    // Keyboard navigation (← →)
    // Touch swipe support
    // Progress tracking
  </script>
</body>
</html>
```

**Yêu cầu thiết kế:**
- Nền tối chuyên nghiệp (`#0D0C09`) hoặc nền sáng tùy yêu cầu
- Typography đẹp: Cormorant Garamond / DM Sans
- Màu accent: gold `#C99A35`
- Mỗi slide: 1 ý chính, không quá 50 chữ
- Icons: emoji hoặc Unicode symbols
- Animation: fade-in mượt mà

### Bước 4 — Lưu file
- Lưu: `outputs/slides-[chủ đề]-[ngày].html`
- Thông báo: "✅ Đã tạo [X] slides! Mở file HTML để xem, dùng phím ← → để điều hướng."

## Tips
- Mỗi slide chỉ có 1 thông điệp chính
- Dùng số liệu cụ thể thay vì câu chung chung
- Bullet points tối đa 4 điểm/slide
- Cover slide phải ấn tượng
