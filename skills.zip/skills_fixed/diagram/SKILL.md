---
name: diagram
description: Tạo sơ đồ Excalidraw chuyên nghiệp (Diagram Generator). Kích hoạt khi người dùng gõ "diagram", "tạo sơ đồ", "vẽ flowchart", "excalidraw". Tạo file JSON Excalidraw sẵn sàng import, không cần vẽ tay hay dùng tool phức tạp.
---

# 📐 Diagram Generator Skill

## Mục tiêu
Mô tả bằng lời → nhận file Excalidraw JSON chuyên nghiệp, import ngay vào excalidraw.com. Không cần kéo thả thủ công.

## Khi nào kích hoạt
- Người dùng gõ: `diagram [mô tả]`, `tạo sơ đồ X`, `vẽ flowchart X`
- Ví dụ: `diagram quy trình tuyển dụng`, `diagram hệ thống microservices`

## Quy trình thực hiện

### Bước 1 — Phân tích yêu cầu
Xác định:
- Loại diagram: flowchart / ER diagram / mind map / network / sequence
- Các nodes/entities chính
- Các connections/relationships
- Hướng: top-to-bottom hay left-to-right

### Bước 2 — Tạo Excalidraw JSON

Tạo file `.excalidraw` (JSON) với cấu trúc:

```json
{
  "type": "excalidraw",
  "version": 2,
  "source": "https://excalidraw.com",
  "elements": [
    {
      "type": "rectangle",
      "id": "node1",
      "x": 100, "y": 100,
      "width": 160, "height": 60,
      "strokeColor": "#1971c2",
      "backgroundColor": "#d0ebff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "roundness": {"type": 3},
      "label": {"text": "Tên Node"}
    },
    {
      "type": "arrow",
      "id": "edge1",
      "startBinding": {"elementId": "node1"},
      "endBinding": {"elementId": "node2"},
      "strokeColor": "#343a40"
    }
  ],
  "appState": {
    "gridSize": null,
    "viewBackgroundColor": "#ffffff"
  }
}
```

**Màu sắc theo loại node:**
- 🔵 Xanh dương: action/process (`#d0ebff`)
- 🟢 Xanh lá: success/positive (`#d3f9d8`)
- 🔴 Đỏ: error/stop (`#ffe3e3`)
- 🟡 Vàng: decision/warning (`#fff3bf`)
- ⬜ Trắng: neutral/default

### Bước 3 — Lưu file
- Lưu: `outputs/diagram-[tên]-[ngày].excalidraw`
- Hướng dẫn import:
  > "Mở excalidraw.com → nhấn nút menu (☰) → Open → chọn file này"

### Bước 4 — Thêm SVG preview (tùy chọn)
Nếu người dùng muốn xem ngay, tạo thêm file SVG preview đơn giản.

## Lưu ý
- Đặt nodes cách nhau ít nhất 50px
- Dùng arrow có label để giải thích relationship
- Group các nodes liên quan vào cùng vùng
- Diagram nên fit vào màn hình 1080p (max 1800x900px)
