---
name: visualize
description: Giải thích trực quan bất kỳ khái niệm nào (Visual Explainer). Kích hoạt khi người dùng gõ "visualize", "giải thích trực quan", "tạo diagram tương tác", "vẽ sơ đồ". Tạo trang web HTML tương tác với diagram, animation và typography đẹp để giải thích khái niệm phức tạp.
---

# 🎨 Visual Explainer Skill

## Mục tiêu
Biến bất kỳ khái niệm phức tạp nào thành trang web tương tác với diagram đẹp, animation mượt, dễ hiểu. Hoàn hảo để giải thích quy trình kinh doanh, kiến trúc hệ thống, hoặc bất kỳ concept nào.

## Khi nào kích hoạt
- Người dùng gõ: `visualize [concept]`, `giải thích trực quan X`, `tạo diagram X`
- Ví dụ: `visualize quy trình bán hàng`, `visualize cách Claude Co-work hoạt động`

## Quy trình thực hiện

### Bước 1 — Hiểu concept
Xác định:
- Đây là quy trình (A→B→C) hay cấu trúc (A bao gồm B, C)?
- Có bao nhiêu bước/thành phần?
- Mối quan hệ giữa các phần là gì?
- Đối tượng xem là ai?

### Bước 2 — Chọn loại visual
- **Flowchart**: quy trình tuần tự
- **Mind map**: các khái niệm liên quan
- **Timeline**: theo thứ tự thời gian
- **Comparison**: so sánh A vs B
- **Architecture**: cấu trúc hệ thống
- **Funnel**: phễu/stages

### Bước 3 — Tạo HTML Interactive

```html
<!DOCTYPE html>
<html>
<style>
  /* Dark background với glassmorphism */
  /* SVG animations */
  /* Hover effects */
  /* Smooth transitions */
  /* Color-coded components */
</style>
<body>
  <!-- Title + description -->
  <!-- Main visual (SVG hoặc CSS diagram) -->
  <!-- Interactive elements (click để xem chi tiết) -->
  <!-- Legend -->
</body>
</html>
```

**Yêu cầu:**
- Sử dụng SVG hoặc CSS thuần (không cần thư viện ngoài)
- Hover/click để reveal thông tin chi tiết
- Animation: các phần tử xuất hiện tuần tự
- Màu sắc có ý nghĩa (xanh = tốt, đỏ = cảnh báo, vàng = quan trọng)
- Mobile-friendly
- Có legend giải thích màu sắc/ký hiệu

### Bước 4 — Lưu file
- Lưu: `outputs/visual-[concept]-[ngày].html`
- Thông báo kèm mô tả ngắn về những gì được tạo

## Ví dụ outputs
- Sơ đồ kiến trúc Claude Co-work với 4 thành phần
- Quy trình onboarding khách hàng 7 bước
- So sánh Claude Co-work vs Claude Code
- Funnel marketing từ awareness đến purchase
