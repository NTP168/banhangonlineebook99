---
name: research
description: Trợ lý nghiên cứu chuyên sâu (Research Assistant). Kích hoạt khi người dùng gõ "research", "nghiên cứu", "tìm hiểu về", "phân tích", "báo cáo về". Tự động tìm kiếm web, tổng hợp và tạo tài liệu nghiên cứu hoàn chỉnh với nguồn dẫn chứng, dữ liệu và thống kê.
---

# 🔍 Research Assistant Skill

## Mục tiêu
Nhận một chủ đề → trả về tài liệu nghiên cứu hoàn chỉnh, chuyên nghiệp, có nguồn dẫn chứng rõ ràng. Tiết kiệm 30 phút đến 1 giờ nghiên cứu thủ công.

## Khi nào kích hoạt
- Người dùng gõ: `research [chủ đề]`, `nghiên cứu về X`, `phân tích X`, `báo cáo về X`
- Ví dụ: `research Claude Co-work`, `nghiên cứu về AI Marketing 2025`

## Quy trình thực hiện

### Bước 1 — Xác định phạm vi
Hỏi nếu chưa rõ:
- Mục đích nghiên cứu? (học, kinh doanh, đầu tư, marketing...)
- Độ sâu mong muốn? (tóm tắt 1 trang / báo cáo đầy đủ)
- Góc nhìn? (Việt Nam / toàn cầu / cả hai)

### Bước 2 — Tìm kiếm đa nguồn
Tìm kiếm web với ít nhất 3 query khác nhau:
1. Query tổng quan: `"[chủ đề] overview 2025"`
2. Query số liệu: `"[chủ đề] statistics data"`
3. Query xu hướng: `"[chủ đề] trends Vietnam"`

### Bước 3 — Tổng hợp & Phân tích
Cấu trúc tài liệu:

```markdown
# [Tiêu đề Nghiên Cứu]
**Ngày:** [ngày tháng] | **Người yêu cầu:** [tên nếu có]

## 📋 Tóm Tắt Điều Hành (Executive Summary)
[3-5 câu tóm tắt điểm quan trọng nhất]

## 🔍 Tổng Quan
[Mô tả chủ đề, context, tầm quan trọng]

## 📊 Số Liệu & Thống Kê Quan Trọng
- Số liệu 1: [nguồn]
- Số liệu 2: [nguồn]

## 🔑 Điểm Chính
1. [Insight 1]
2. [Insight 2]
3. [Insight 3]

## ⚠️ Rủi Ro & Thách Thức
[Các điểm cần lưu ý]

## 💡 Khuyến Nghị
[Hành động cụ thể dựa trên nghiên cứu]

## 📚 Nguồn Tham Khảo
- [Nguồn 1](url)
- [Nguồn 2](url)
```

### Bước 4 — Lưu file
- Lưu vào `outputs/research-[chủ đề]-[ngày].md`
- Thông báo hoàn thành kèm tóm tắt ngắn

## Chất lượng đầu ra
- Độ dài: 500-1500 từ tùy độ phức tạp
- Luôn có nguồn dẫn chứng cụ thể
- Số liệu phải có năm xuất bản
- Ngôn ngữ: tiếng Việt trừ thuật ngữ chuyên ngành
